#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include "graphics.h"
#include "genlib.h"
#include "conio.h"

#include <windows.h>
#include <olectl.h>
#include <stdio.h>
#include <mmsystem.h>
#include <wingdi.h>
#include <ole2.h>
#include <ocidl.h>
#include <winuser.h>

#include "extgraph.h"
#include "genlib.h"
#include "simpio.h"
#include "time.h"

#include "imgui.h"
#include "message.h"
#pragma warning(disable:4996)

extern bool selectDataFlag;
extern char currentUser[30];

void saveData();
bool openData(char *textname);
void inputData(int mode);
void selectUser();
void addToRlist();
void selectData();
