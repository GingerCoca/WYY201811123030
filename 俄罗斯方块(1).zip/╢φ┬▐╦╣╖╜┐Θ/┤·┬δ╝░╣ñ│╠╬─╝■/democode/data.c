#include"data.h"
#include"basic.h"

extern int grid[10][20];
char currentUser[30]="defaultuser";

char timedata[30];

char timedatas[12][60];
int scores[12];
char usernames[12][200];
int ranking[12];

extern bool selectDataFlag = 0;

extern struct set *currentSet;
extern struct set I1, I2, S1, Z1, L4, J2, O, T3, S2, Z2, J3, T4, L1, T2, L2, L3, J4, J1, T1;
extern int csx, csy;
extern int timeInterval;
extern int score;

/*
���浱ǰ��Ϸ����
*/
void saveData()
{

	FILE *fp;
	int i, j, a = 0,b=0,size;
	static char textname[200]="";
	char year[5],month[5],day[5],hour[5],minute[5],second[5];

	timedata[0] = '\0';

	if ((fp = fopen("data.txt", "w")) == NULL)
	{
		exit(0);
	}
	
	
	
	for (i = 0; i < 10; i++)
		for (j = 0; j < 20; j++)
		{
			fprintf(fp, "%d\n", grid[i][j]);      //���뾲ֹ��������
		}
	
	if (currentSet == &I1)	a = 1;
	if (currentSet == &I2)	a = 2;
	if (currentSet == &S1)	a = 3;
	if (currentSet == &Z1)	a = 4;
	if (currentSet == &L4)	a = 5;
	if (currentSet == &J2)	a = 6;
	if (currentSet == &O)	a = 7;
	if (currentSet == &T3)	a = 8;
	if (currentSet == &S2)	a = 9;
	if (currentSet == &Z2)	a = 10;
	if (currentSet == &J3)	a = 11;
	if (currentSet == &T4)	a = 12;
	if (currentSet == &L1)	a = 13;
	if (currentSet == &T2)	a = 14;
	if (currentSet == &L2)	a = 15;
	if (currentSet == &L3)	a = 16;
	if (currentSet == &J4)	a = 17;
	if (currentSet == &J1)	a = 18;
	if (currentSet == &T1)	a = 19;

	fprintf(fp, "%d\n", a);

	if (theNextSet == &I1)	b = 1;
	if (theNextSet == &I2)	b = 2;
	if (theNextSet == &S1)	b = 3;
	if (theNextSet == &Z1)	b = 4;
	if (theNextSet == &L4)	b = 5;
	if (theNextSet == &J2)	b = 6;
	if (theNextSet == &O)	b = 7;
	if (theNextSet == &T3)	b = 8;
	if (theNextSet == &S2)	b = 9;
	if (theNextSet == &Z2)	b = 10;
	if (theNextSet == &J3)	b = 11;
	if (theNextSet == &T4)	b = 12;
	if (theNextSet == &L1)	b = 13;
	if (theNextSet == &T2)	b = 14;
	if (theNextSet == &L2)	b = 15;
	if (theNextSet == &L3)	b = 16;
	if (theNextSet == &J4)	b = 17;
	if (theNextSet == &J1)	b = 18;
	if (theNextSet == &T1)	b = 19;

	fprintf(fp, "%d\n", b);
	
	//���붯̬��������
	fprintf(fp, "%d\n", csx);
	fprintf(fp, "%d\n", csy);
	
	fprintf(fp, "%d\n", timeInterval);               //�����ٶȺ͵÷� 
	fprintf(fp, "%d\n", score);

	fprintf(fp, "%d\n", colorNO);            
	fprintf(fp, "%d\n", nextColorNO);

	fprintf(fp, "%s", currentUser);
	//�����û���

	if (fclose(fp))
	{
		exit(0);
	}
	
	time_t timep;           //���ϵͳʱ��
	struct tm *p;
	time (&timep); 
	p = gmtime(&timep);

	/*itoa(1900 + p->tm_year, year, 10);      //��ʱ������������תΪ�ַ�����
	fprintf( month, "%02d",1 + p->tm_mon);
	fprintf( day, "%02d",p->tm_mday);
	fprintf( hour, "%02d",8 + p->tm_hour);
	fprintf( minute, "%02d",p->tm_min);
	fprintf( second,"%02d", p->tm_sec);*/


	itoa(1900 + p->tm_year, year, 10);      //��ʱ������������תΪ�ַ�����
	itoa(1 + p->tm_mon, month, 10);
	itoa(p->tm_mday, day, 10);
	itoa(8 + p->tm_hour, hour, 10);
	itoa(p->tm_min, minute, 10);
	itoa(p->tm_sec, second, 10);

	strcat(timedata,year);        //����ʱ��
	strcat(timedata,month); 
	strcat(timedata,day); 
	strcat(timedata,hour); 
	strcat(timedata,minute); 
	strcat(timedata,second);
	
	
	strcpy(textname, currentUser);

	strcat(textname,"-");
	strcat(textname,timedata);//�����û�����ʱ��
	strcat(textname, ".txt");
	rename("data.txt", textname);
	
	if ((fp = fopen("datalist.txt", "a")) == NULL)      //���ļ���д��textlist�ļ�
	{
		exit(0);
	}

	fprintf(fp, "\n%s", textname);

	if (fclose(fp))
	{
		exit(0);
	}
	
	
	return 0;

}

/*
�򿪴����ļ�������Ϸ�浵
*/
bool openData(char *string)
{

	FILE *fp;
	int i, j, a,b;
	char temp[80];

	if ((fp = fopen(string, "r")) == NULL)
	{
		return 0;
	}
	


	for (i = 0; i < 10; i++)
		for (j = 0; j < 20; j++)
		{
			fscanf(fp, "%d", &grid[i][j]);
		}
	


	fscanf(fp, "%d", &a);

	if (a == 1)		currentSet = &I1;
	if (a == 2)		currentSet = &I2;
	if (a == 3)		currentSet = &S1;
	if (a == 4)		currentSet = &Z1;
	if (a == 5)		currentSet = &L4;
	if (a == 6)		currentSet = &J2;
	if (a == 7)		currentSet = &O;
	if (a == 8)		currentSet = &T3;
	if (a == 9)		currentSet = &S2;
	if (a == 10)	currentSet = &Z2;
	if (a == 11)	currentSet = &J3;
	if (a == 12)	currentSet = &T4;
	if (a == 13)	currentSet = &L1;
	if (a == 14)	currentSet = &T2;
	if (a == 15)	currentSet = &L2;
	if (a == 16)	currentSet = &L3;
	if (a == 17)	currentSet = &J4;
	if (a == 18)	currentSet = &J1;
	if (a == 19)	currentSet = &T1;

	fscanf(fp, "%d", &b);

	if (b == 1)		theNextSet = &I1;
	if (b == 2)		theNextSet = &I2;
	if (b == 3)		theNextSet = &S1;
	if (b == 4)		theNextSet = &Z1;
	if (b == 5)		theNextSet = &L4;
	if (b == 6)		theNextSet = &J2;
	if (b == 7)		theNextSet = &O;
	if (b == 8)		theNextSet = &T3;
	if (b == 9)		theNextSet = &S2;
	if (b == 10)	theNextSet = &Z2;
	if (b == 11)	theNextSet = &J3;
	if (b == 12)	theNextSet = &T4;
	if (b == 13)	theNextSet = &L1;
	if (b == 14)	theNextSet = &T2;
	if (b == 15)	theNextSet = &L2;
	if (b == 16)	theNextSet = &L3;
	if (b == 17)	theNextSet = &J4;
	if (b == 18)	theNextSet = &J1;
	if (b == 19)	theNextSet = &T1;

	fscanf(fp, "%d", &csx);
	fscanf(fp, "%d", &csy);

	fscanf(fp, "%d", &timeInterval);               //�����ٶȺ͵÷� 
	fscanf(fp, "%d", &score);

	fscanf(fp, "%d", &colorNO);
	fscanf(fp, "%d", &nextColorNO);

	fscanf(fp, "\n%s", currentUser);

	
	if (fclose(fp))
	{
		exit(0);
	}
	
	return 1;
}


/*
��ȡ�ļ����Ҫ�򿪵��ļ�������
*/
void inputData(int mode)
{
	FILE *fp;

	double fH = GetFontHeight();
	int i = 0;
	double fW, nix, niy =iy- 3 * unitLength, w;
	fW = 1.5 * unitLength;
	int userNumber;

	nix = 2 * fH;
	w = winwidth / 5;

	static char textname[200] = "";

	if ((fp = fopen("datalist.txt", "r")) == NULL)
	{
		exit(0);
	}


	SetPenColor("Dark Gray");
	drawBox(nix, iy - 3 * unitLength, w, 3 * unitLength, 1, "����浵���ƣ�", 'M', "White");
	i += 2;

	textbox(GenUIID(0), nix, niy - 2.5*fH, w, 2 * fH, textname, sizeof(textname));

	i = 3;

		{
			
			if (button(GenUIID(0), nix, iy - 1.5*fW - i * fW, w, fW, "���ļ�"))
			{
				selectDataFlag = FALSE;
				if (openData(textname))
				{
					endmFlag = 0;
				}
				else
				{
					MessageBox(NULL, "δ�ҵ����ļ���","��ʾ", 1);
				}

			}

			
		}


	if (fclose(fp))
	{
		exit(0);
	}
	return 0;


}

/*
��ʾ�ղش浵
*/
void selectData()
{
	FILE *fp;
	
	double fH = GetFontHeight();
	int i=0;
	double fW, nix, niy, w;
	fW = 1.5 * unitLength;
	int userNumber;

	nix = 2 * fH;
	w = winwidth / 5;

	char textname[200] = "";

	if ((fp = fopen("datalist.txt", "r")) == NULL)
	{
		exit(0);
	}


	SetPenColor("Dark Gray");
	drawBox(nix, iy - 3 * unitLength , w, 3 * unitLength, 1,"���ղش浵",'M',"White");
	i += 2;

	fscanf(fp,"\n",textname);

		{
			 if(!feof(fp)) fscanf(fp, "%s", textname); else textname[0]='\0';
			if (button(GenUIID(0), nix, iy - fW - i * fW, w, fW, textname))
			{

				selectDataFlag = FALSE;
				openData(textname);
			}

			i++;
		}
		{
		{
			if(!feof(fp)) fscanf(fp, "%s", textname); else textname[0]='\0';
			if (button(GenUIID(0), nix, iy - fW - i * fW, w, fW, textname))
			{

				selectDataFlag = FALSE;
				openData(textname);
			}

			i++;
		}

		{
			if(!feof(fp)) fscanf(fp, "%s", textname); else textname[0]='\0';
			if (button(GenUIID(0), nix, iy - fW - i * fW, w, fW, textname))
			{

				selectDataFlag = FALSE;
				openData(textname);
			}

			i++;
		}

		{
			if(!feof(fp)) fscanf(fp, "%s", textname); else textname[0]='\0';
			if (button(GenUIID(0), nix, iy - fW - i * fW, w, fW, textname))
			{

				selectDataFlag = FALSE;
				openData(textname);

			}

			i++;
		}

		{
			if(!feof(fp)) fscanf(fp, "%s", textname); else textname[0]='\0';
			if (button(GenUIID(0), nix , iy - fW - i * fW, w, fW, textname))
			{
				selectDataFlag = FALSE;
				openData(textname);

			}

			i++;
		}
	}


		if (fclose(fp))
		{
			exit(0);
		}
		return 0;

	
}

/*
��ȡ���а�����
*/
void getRlistData()
{
	FILE *fp;
	int i;

	if (fp = fopen("rankinglist.txt", "r") == NULL)
	{
		exit(0);
	}

	for (i = 1; i < 11; i++)
	{
		fscanf(fp, "%s", timedatas[i]);
		fscanf(fp, "%s", usernames[i]);
		fscanf(fp, "%d", &scores[i]);
	}

	if (fclose(fp))
	{
		exit(0);
	}
	return 0;
}


/*
�жϸ���Ϸ�ܷ�������а������������
*/
void addToRlist()
{
	FILE *fp;
	int i = 0, k, a;
	char temp[100] = "";
	double fH = GetFontHeight();
	char ctime[10][80], username[10][80];
	int rscore[10];


	char timedata[30], year[5], month[5], day[5], hour[5], minute[5], second[5];

	timedata[0] = '\0';


	time_t timep;           //���ϵͳʱ��
	struct tm *p;
	time(&timep);
	p = gmtime(&timep);

	itoa(1900 + p->tm_year, year, 10);      //��ʱ������������תΪ�ַ�����
	itoa(1 + p->tm_mon, month, 10);
	itoa(p->tm_mday, day, 10);
	itoa(8 + p->tm_hour, hour, 10);
	itoa(p->tm_min, minute, 10);
	itoa(p->tm_sec, second, 10);

	strcat(timedata, year);        //����ʱ��
	strcat(timedata, month);
	strcat(timedata, day);
	strcat(timedata, hour);
	strcat(timedata, minute);
	strcat(timedata, second);


	if ((fp = fopen("rankinglist.txt", "r+")) == NULL)
	{
		exit(0);
	}

	i = 0;

	while (i < 10)
	{


		fscanf(fp, "%s", ctime[i]);

		fscanf(fp, "%s", username[i]);

		fscanf(fp, "%d", &rscore[i]);


		i++;
	}

	rewind(fp);

	i = 9;


	while (i >= 0)
	{
		if (score > rscore[i])
		{
			i--;
		}
		else
			break;
	}

	k = i + 1;
	i = 0;


	if (k < 10)
	{
		while (i < 10 && i != k)
		{
			fprintf(fp, "%s %s %d\n", ctime[i], username[i], rscore[i]);
			i++;
		}

		fprintf(fp, "%s %s %d\n", timedata, currentUser, score);

		while (i < 10)
		{
			fprintf(fp, "%s %s %d\n", ctime[i], username[i], rscore[i]);
			i++;
		}

	}





	if (fclose(fp))
	{
		exit(0);
	}
	return 0;
}


/*
ѡ���û���������δʹ�ã�
*/
void selectUser()
{
	FILE *fp;
	int i = 0, j, a;
	char textname[800] = "";

	if ((fp = fopen("datalist.txt", "r")) == NULL)
	{
		exit(0);
	}
	
	
	fscanf(fp, "%s", textname);
	if (button(GenUIID(16), ix - 3.5 * unitLength, iy - 3 * unitLength - i * 3 * unitLength, winwidth / 4, 3 * unitLength, textname))
	{
		
		selectDataFlag = FALSE;
		openData(textname);
	}
	i++;

	{
		fscanf(fp, "%s", textname);
		if (button(GenUIID(16), ix - 3.5 * unitLength, iy - 3 * unitLength - i * 3 * unitLength, winwidth / 4, 3 * unitLength, textname))
		{
			selectDataFlag = FALSE;
			openData(textname);
		}
		i++;


		fscanf(fp, "%s", textname);
		if (button(GenUIID(16), ix - 3.5 * unitLength, iy - 3 * unitLength - i * 3 * unitLength, winwidth / 4, 3 * unitLength, textname))
		{
			
			selectDataFlag = FALSE;
			openData(textname);
		}
		i++;

		fscanf(fp, "%s", textname);
		if (button(GenUIID(16), ix - 3.5 * unitLength, iy - 3 * unitLength - i * 3 * unitLength, winwidth / 4, 3 * unitLength, textname))
		{
			
			selectDataFlag = FALSE;
			openData(textname);
		}
		i++;

		fscanf(fp, "%s", textname);
		if (button(GenUIID(16), ix - 3.5 * unitLength, iy - 3 * unitLength - i * 3 * unitLength, winwidth / 4, 3 * unitLength, textname))
		{
			
			selectDataFlag = FALSE;
			openData(textname);
		}
		i++;

		fscanf(fp, "%s", textname);
		if (button(GenUIID(16), ix - 3.5 * unitLength, iy - 3 * unitLength - i * 3 * unitLength, winwidth / 4, 3 * unitLength, textname))
		{
			
			selectDataFlag = FALSE;
			openData(textname);
		}
		i++;



		
	}

	if (fclose(fp))
	{
		exit(0);
	}
	return 0;

}

