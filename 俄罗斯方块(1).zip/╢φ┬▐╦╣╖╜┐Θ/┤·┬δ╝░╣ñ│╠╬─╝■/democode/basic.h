
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include "graphics.h"
#include "genlib.h"
#include "conio.h"

#include <windows.h>
#include <olectl.h>
#include <stdio.h>
#include <mmsystem.h>
#include <wingdi.h>
#include <ole2.h>
#include <ocidl.h>
#include <winuser.h>

#include "extgraph.h"
#include "genlib.h"
#include "simpio.h"

#include "imgui.h"
#include "message.h"

#define GridSideLength 4
#define SCREENTIMER 0
#define  GAMETIMER 1

extern double unitLength;
extern int action;
extern int score;
extern double ix, iy;
extern colorNO, nextColorNO;

void drawGameArea();
void drawNextSet();
void showScore();
void initNextSet();
void display();
void drawFrame();
void drawBlocks();
void drawSingleBlock();
void test();
void drawOutline(double x, double y, double width, double height);

void TimerEventProcess(int timerID);
void MouseEventProcess(int x, int y, int button, int event);
void CharEventProcess(char ch);

void renewStatus();
bool endCheck();
void endGame();
bool dropEndJudge();
void nextSet(int flag);
void drawCurrentSet();
void addToGrids();
void keyboardEventProcess(int key, int event);
void rotate();
bool rightMoveJudge();
void initSetDesc();
void create_I1();
void create_I2();
void create_S1();
void create_Z1();
void create_L4();
void create_J2();
void create_O();
void create_T3();
void create_S2();
void create_Z2();
void create_L1();
void create_J3();
void create_T4();
void create_L1();
void create_T2();
void create_L2();
void create_L3();
void create_J4();
void create_J1();
void create_T1();
void eliminationCheck();
void eliminate(int k);