#include "graphics.h"
#include "extgraph.h"
#include "genlib.h"
#include "simpio.h"
#include "conio.h"
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>

#include <windows.h>
#include <olectl.h>
#include <mmsystem.h>
#include <wingdi.h>
#include <ole2.h>
#include <ocidl.h>
#include <winuser.h>

#include "imgui.h"

#define DEMO_MENU
#define DEMO_BUTTON
#define  GAMETIMER 1

extern double winwidth, winheight;
extern int grid[10][20];
extern struct set *currentSet, *theNextSet;
extern int timeInterval;
extern bool selectUserFlag;

void drawMenu();

void drawButtons();

void speedUp();

void slowDown();

void resetScore();

void gridsClear();

void drawInfoBar();

void showUserName(username, NO);

