#include "message.h"
#include "basic.h"
#include "data.h"

bool endmFlag = 0,alreadyLogin=0;
int userNumber;

	
/*
��ʾ��Ϸ������Ϣ
*/
void endGameMessage()
{
	double nix, niy;
	char scoreCla[80] = "";

	nix = ix + 3.5 * unitLength;
	niy = iy - 8 * unitLength;

	drawMessageBox();
	sprintf(scoreCla, "������յ÷֣�%d", score);
	
	


	//void drawBox(double x, double y, double w, double h, int fillflag, char *label, char xalignment, char *labelColor);
	SetPenColor("White");
	drawBox(ix, iy - 15 * unitLength, 10 * unitLength, 10 * unitLength, 1, scoreCla, 'M', "Black");
	
	drawOutline(ix, iy - 5 * unitLength, 10 * unitLength, 10 * unitLength);
	drawLabel(nix, niy, "��Ϸ������");
}

/*
��Ϣ����ƺ���
*/
void drawMessageBox()
{
	SetPenColor("White");

	StartFilledRegion(1);
	drawOutline(ix, iy - 5 * unitLength, 10 * unitLength, 10 * unitLength);
	EndFilledRegion();

	SetPenColor("Black");
	drawOutline(ix, iy - 5 * unitLength, 10 * unitLength, 10 * unitLength);

}

/*
������Ϣ��ʾ����
*/
void drawMessages()
{
	if (endmFlag == TRUE)
	{
		endGameMessage();
	}
	if (selectDataFlag == TRUE)
	{
		selectData();
	}
	else
	{
		inputData(1);
	}
	if (selectUserFlag == TRUE)
	{
		selectUser();
	}
	if (alreadyLogin == TRUE)
	{
		showUserInfo(currentUser);
	}
	else
	{
		login();
	}
}

/*
�������а�
*/
void drawRankingList()
{
	FILE *fp;
	int i = 0, j, a;
	char temp[100] = "";
	double fH = GetFontHeight();

	double x = ix + 19 * GridSideLength;
	double y = iy - 3 * fH;
	double gap = 6 * fH;
	double h = winwidth / 23;

	drawOutline(ix + 9 * h, iy, 15 * GridSideLength, 20 * GridSideLength);

	if ((fp = fopen("rankinglist.txt", "r")) == NULL)
	{
		exit(0);
	}


	strcpy(temp, "���а�");
	drawLabel(x + 1.2*gap, y, temp);

	y -= 2 * fH;

	strcpy(temp, "ʱ��");
	drawLabel(x, y, temp);

	strcpy(temp, "�û���");
	drawLabel(x + 1.5 * gap, y, temp);

	strcpy(temp, "����");
	drawLabel(x + 2.5 * gap, y, temp);

	y -= 2 * fH;

	while (i < 10)
	{


		fscanf(fp, "%s", temp);
		drawLabel(x, y, temp);

		fscanf(fp, "%s", temp);
		drawLabel(x + 1.5 * gap, y, temp);

		fscanf(fp, "%s", temp);
		drawLabel(x + 2.5 * gap, y, temp);

		y -= 2 * fH;

		i++;
	}

	if (fclose(fp))
	{
		exit(0);
	}
	return 0;

}

/*
��¼����
*/
void login()
{
	double fH = GetFontHeight();
	double h = fH * 2; // �ؼ��߶�
	double w = 5 * unitLength; // �ؼ�����
	double x = ix + 10.5 * unitLength;
	double y = iy - 9 * unitLength;
	static char username[80] = "defaultuser";
	int userID;
	int i = 0, flag = 0;

	SetPenColor("Black");

	//ix + 10.5 * unitLength, iy - 0.5*unitLength, 5 * unitLength, 4 * unitLength

	drawLabel(x, y, "�����û�����");
	if (textbox(GenUIID(0), x, y - 2.5*fH, w, h, username, sizeof(username)))
	{

	}
	if (button(GenUIID(0), x, y - 2.5*fH - 1.25*h, w, h, "��¼/�����û�"))
	{

		if (strlen(username) >= 75)
		{
			MessageBox(NULL, "�û���̫����", "��ʾ", 0);
			flag = 1;
		}

		while (i < strlen(username))
		{
			if (username[i] == ' ')
			{
				MessageBox(NULL, "�û����в��ð����ո�", "��ʾ", 0);
				flag = 1;

			}
			i++;
		}

		if (flag == 0)
		{
			if (userID = checkUser(username))
			{
				alreadyLogin = TRUE;
				strcpy(currentUser, username);
			}
			else
			{

				createUser(username);
				alreadyLogin = TRUE;
				strcpy(currentUser, username);
				MessageBox(NULL, "�ɹ��������û���", "��ʾ", 0);
			}
		}
		else
		{
			;
		}

	}


}

/*
����û������Ƿ����
*/
int checkUser(char *username)
{

	FILE *fp;
	int i = 1;
	char comp[80];

	if ((fp = fopen("userlist.txt", "r")) == NULL)
	{
		exit(0);
	}

	fscanf(fp, "%d", &userNumber);

	while (!feof(fp))
	{
		fscanf(fp, "%s", comp);
		if (strcmp(comp, username) == 0)
		{
			if (fclose(fp))
				{
					exit(0);
				}
			return i;
		}
	}

	if (fclose(fp))
	{
		exit(0);
	}
	return 0;


}

/*
��ʾ�û���Ϣ
*/
void showUserInfo(char *username)
{
	double fH = GetFontHeight();
	double h = fH * 2; // �ؼ��߶�
	double w = 5 * unitLength; // �ؼ�����
	double x = ix + 10.5 * unitLength;
	double y = iy - 9 * unitLength;

	SetPenColor("Black");
	drawLabel(x+h, y, "��ӭ����");
	drawLabel(x+h, y - 2 * fH, username);
	if (button(GenUIID(0), x, y - 2.5*fH - 1.25*h, w, h, "�˳���¼"))
	{
		alreadyLogin = 0;
		strcpy(currentUser, "defaultUser");
	}


	drawRectangle(x, y - 2.5*fH - 1.25*h, w, 3 * h, 0);


}

/*
�������û�
*/
void createUser(char *username)
{
	FILE *fp;
	int i = 1;
	char comp[80];

	if ((fp = fopen("userlist.txt", "a+")) == NULL)
	{
		exit(0);
	}

	fprintf(fp, "%s\n", username);

	if (fclose(fp))
	{
		exit(0);
	}
	return 0;
}